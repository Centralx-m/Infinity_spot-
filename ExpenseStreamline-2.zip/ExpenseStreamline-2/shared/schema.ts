import { pgTable, text, serial, integer, boolean, timestamp, json, numeric, doublePrecision } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// API Keys
export const apiKeys = pgTable("api_keys", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  apiKey: text("api_key").notNull(),
  apiSecret: text("api_secret").notNull(),
  passphrase: text("passphrase").notNull(),
  encryptionIv: text("encryption_iv").notNull(),
  encryptionSalt: text("encryption_salt").notNull(),
});

export const insertApiKeySchema = createInsertSchema(apiKeys).omit({
  id: true,
  encryptionIv: true,
  encryptionSalt: true,
});

export type InsertApiKey = z.infer<typeof insertApiKeySchema>;
export type ApiKey = typeof apiKeys.$inferSelect;

// Trading Bots
export const tradingBots = pgTable("trading_bots", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  tradingPair: text("trading_pair").notNull(),
  apiKeyId: integer("api_key_id").notNull(),
  upperPrice: numeric("upper_price").notNull(),
  lowerPrice: numeric("lower_price").notNull(),
  gridLines: integer("grid_lines").notNull(),
  gridType: text("grid_type").notNull(), // "arithmetic" or "geometric"
  investmentAmount: numeric("investment_amount").notNull(),
  profitPerGrid: numeric("profit_per_grid").notNull(),
  isActive: boolean("is_active").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  gridData: json("grid_data").$type<number[]>(),
});

export const insertTradingBotSchema = createInsertSchema(tradingBots).omit({
  id: true,
  createdAt: true,
  gridData: true,
});

export type InsertTradingBot = z.infer<typeof insertTradingBotSchema>;
export type TradingBot = typeof tradingBots.$inferSelect;

// Transactions
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  botId: integer("bot_id").notNull(),
  tradingPair: text("trading_pair").notNull(),
  type: text("type").notNull(), // "buy" or "sell"
  price: numeric("price").notNull(),
  amount: numeric("amount").notNull(),
  value: numeric("value").notNull(),
  profit: numeric("profit"),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  orderId: text("order_id").notNull(),
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  timestamp: true,
});

export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;

// Dashboard Stats
export const dashboardStats = pgTable("dashboard_stats", {
  id: serial("id").primaryKey(),
  totalAssets: numeric("total_assets").notNull(),
  dailyProfit: numeric("daily_profit").notNull(),
  dailyProfitPercentage: numeric("daily_profit_percentage").notNull(),
  activeBots: integer("active_bots").notNull(),
  totalBots: integer("total_bots").notNull(),
  completedTrades: integer("completed_trades").notNull(),
  todayTrades: integer("today_trades").notNull(),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

// Price Data
export const priceData = pgTable("price_data", {
  id: serial("id").primaryKey(),
  tradingPair: text("trading_pair").notNull(),
  price: doublePrecision("price").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

// Helper schemas for API responses
export const priceCandleSchema = z.object({
  time: z.number(),
  open: z.number(),
  high: z.number(),
  low: z.number(),
  close: z.number(),
  volume: z.number(),
});

export type PriceCandle = z.infer<typeof priceCandleSchema>;

export const gridBotStatsSchema = z.object({
  id: z.number(),
  name: z.string(),
  tradingPair: z.string(),
  profit24h: z.number(),
  profit24hPercentage: z.number(),
  status: z.enum(["active", "paused", "stopped"]),
  gridRange: z.object({
    lower: z.number(),
    upper: z.number(),
  }),
  gridLines: z.number(),
  createdAt: z.string(),
});

export type GridBotStats = z.infer<typeof gridBotStatsSchema>;

export const dashboardStatsSchema = z.object({
  totalAssets: z.number(),
  dailyProfit: z.number(),
  dailyProfitPercentage: z.number(),
  activeBots: z.number(),
  totalBots: z.number(),
  completedTrades: z.number(),
  todayTrades: z.number(),
});

export type DashboardStats = z.infer<typeof dashboardStatsSchema>;
