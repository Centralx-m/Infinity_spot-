import * as crypto from 'crypto';

// Encryption/decryption for API keys
export function encrypt(text: string, masterKey: string): { encryptedData: string; iv: string; salt: string } {
  // Generate a random salt
  const salt = crypto.randomBytes(16).toString('hex');
  
  // Create a key from the master key and salt
  const key = crypto.scryptSync(masterKey, salt, 32);
  
  // Create an initialization vector
  const iv = crypto.randomBytes(16);
  
  // Create cipher
  const cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
  
  // Encrypt the data
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  
  return {
    encryptedData: encrypted,
    iv: iv.toString('hex'),
    salt,
  };
}

export function decrypt(encryptedData: string, masterKey: string, iv: string, salt: string): string {
  // Create key from the master key and salt
  const key = crypto.scryptSync(masterKey, salt, 32);
  
  // Convert IV from hex string to Buffer
  const ivBuffer = Buffer.from(iv, 'hex');
  
  // Create decipher
  const decipher = crypto.createDecipheriv('aes-256-cbc', key, ivBuffer);
  
  // Decrypt the data
  let decrypted = decipher.update(encryptedData, 'hex', 'utf8');
  decrypted += decipher.final('utf8');
  
  return decrypted;
}

// HMAC signature generation for Bitget API
export function generateSignature(timestamp: string, method: string, requestPath: string, body: string | null, secretKey: string): string {
  const message = timestamp + method.toUpperCase() + requestPath + (body || '');
  return crypto.createHmac('sha256', secretKey).update(message).digest('base64');
}
