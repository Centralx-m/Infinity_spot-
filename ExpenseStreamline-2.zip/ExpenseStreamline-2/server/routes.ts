import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { BitgetApi } from "./api/bitget";
import { encrypt, decrypt } from "./utils/crypto";
import {
  insertApiKeySchema,
  insertTradingBotSchema,
  insertTransactionSchema
} from "@shared/schema";

// Utility to get master key for encryption
function getMasterKey(): string {
  const masterKey = process.env.ENCRYPTION_KEY;
  if (!masterKey) {
    throw new Error("ENCRYPTION_KEY environment variable is not set");
  }
  return masterKey;
}

// Utility to create BitgetApi instance for a specific API key
async function createBitgetApiForKey(apiKeyId: number): Promise<BitgetApi> {
  const apiKey = await storage.getApiKey(apiKeyId);
  if (!apiKey) {
    throw new Error(`API key with ID ${apiKeyId} not found`);
  }

  const masterKey = getMasterKey();
  const secretKey = decrypt(apiKey.apiSecret, masterKey, apiKey.encryptionIv, apiKey.encryptionSalt);
  const passphrase = decrypt(apiKey.passphrase, masterKey, apiKey.encryptionIv, apiKey.encryptionSalt);

  return new BitgetApi({
    apiKey: apiKey.apiKey,
    secretKey,
    passphrase
  });
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // API Key Routes
  app.get("/api/keys", async (req, res) => {
    try {
      const keys = await storage.getApiKeys();
      // Don't send sensitive data to client
      const sanitizedKeys = keys.map(({ id, name }) => ({ id, name }));
      res.json(sanitizedKeys);
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  app.post("/api/keys", async (req, res) => {
    try {
      const apiKeyData = insertApiKeySchema.parse(req.body);
      const masterKey = getMasterKey();

      // Encrypt sensitive data
      const secretEncryption = encrypt(apiKeyData.apiSecret, masterKey);
      const passphraseEncryption = encrypt(apiKeyData.passphrase, masterKey);

      const apiKey = await storage.createApiKey(
        {
          name: apiKeyData.name,
          apiKey: apiKeyData.apiKey,
          apiSecret: secretEncryption.encryptedData,
          passphrase: passphraseEncryption.encryptedData,
        },
        {
          iv: secretEncryption.iv,
          salt: secretEncryption.salt,
        }
      );

      // Don't send sensitive data back to client
      res.status(201).json({
        id: apiKey.id,
        name: apiKey.name,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        res.status(500).json({ error: (error as Error).message });
      }
    }
  });

  app.delete("/api/keys/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteApiKey(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Test API Key
  app.post("/api/keys/test", async (req, res) => {
    try {
      const { apiKey, apiSecret, passphrase } = req.body;
      
      // Create temporary BitgetApi instance with provided credentials
      const bitgetApi = new BitgetApi({
        apiKey,
        secretKey: apiSecret,
        passphrase
      });
      
      // Try to get account info to test the connection
      await bitgetApi.getAccountInfo();
      
      res.json({ success: true, message: "API key connection successful" });
    } catch (error) {
      res.status(400).json({ 
        success: false, 
        message: `API key test failed: ${(error as Error).message}` 
      });
    }
  });

  // Trading Bot Routes
  app.get("/api/bots", async (req, res) => {
    try {
      const bots = await storage.getTradingBots();
      res.json(bots);
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  app.get("/api/bots/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const bot = await storage.getTradingBot(id);
      
      if (!bot) {
        return res.status(404).json({ error: "Bot not found" });
      }
      
      res.json(bot);
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  app.post("/api/bots", async (req, res) => {
    try {
      const botData = insertTradingBotSchema.parse(req.body);
      
      // Create BitgetApi instance for the specified API key
      const bitgetApi = await createBitgetApiForKey(botData.apiKeyId);
      
      // Calculate grid levels
      const gridData = bitgetApi.calculateGridLevels(
        Number(botData.lowerPrice),
        Number(botData.upperPrice),
        botData.gridLines,
        botData.gridType as 'arithmetic' | 'geometric'
      );
      
      // Create bot in storage
      const bot = await storage.createTradingBot(botData, gridData);
      
      res.status(201).json(bot);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        res.status(500).json({ error: (error as Error).message });
      }
    }
  });

  app.patch("/api/bots/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      
      const bot = await storage.updateTradingBot(id, updates);
      
      if (!bot) {
        return res.status(404).json({ error: "Bot not found" });
      }
      
      res.json(bot);
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  app.delete("/api/bots/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteTradingBot(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Start or stop a bot
  app.post("/api/bots/:id/toggle", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const bot = await storage.getTradingBot(id);
      
      if (!bot) {
        return res.status(404).json({ error: "Bot not found" });
      }
      
      // Toggle bot status
      const updatedBot = await storage.updateTradingBot(id, {
        isActive: !bot.isActive
      });
      
      res.json(updatedBot);
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Transaction Routes
  app.get("/api/transactions", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const transactions = await storage.getTransactions(limit);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  app.get("/api/bots/:id/transactions", async (req, res) => {
    try {
      const botId = parseInt(req.params.id);
      const transactions = await storage.getTransactionsByBotId(botId);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  app.post("/api/transactions", async (req, res) => {
    try {
      const transactionData = insertTransactionSchema.parse(req.body);
      const transaction = await storage.createTransaction(transactionData);
      res.status(201).json(transaction);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        res.status(500).json({ error: (error as Error).message });
      }
    }
  });

  // Dashboard Stats Route
  app.get("/api/dashboard", async (req, res) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Bot Stats Route
  app.get("/api/bots/:id/stats", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const stats = await storage.getBotStats(id);
      
      if (!stats) {
        return res.status(404).json({ error: "Bot not found" });
      }
      
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Market Data Routes
  app.get("/api/market/:symbol/ticker", async (req, res) => {
    try {
      const { symbol } = req.params;
      
      // Get any API key to use for this public endpoint
      const apiKeys = await storage.getApiKeys();
      if (apiKeys.length === 0) {
        return res.status(400).json({ error: "No API keys available" });
      }
      
      const bitgetApi = await createBitgetApiForKey(apiKeys[0].id);
      const ticker = await bitgetApi.getTicker(symbol);
      
      res.json(ticker);
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  app.get("/api/market/:symbol/klines", async (req, res) => {
    try {
      const { symbol } = req.params;
      const period = req.query.period as string || '1m';
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      
      // Get any API key to use for this public endpoint
      const apiKeys = await storage.getApiKeys();
      if (apiKeys.length === 0) {
        return res.status(400).json({ error: "No API keys available" });
      }
      
      const bitgetApi = await createBitgetApiForKey(apiKeys[0].id);
      const klines = await bitgetApi.getKlines(symbol, period, limit);
      
      res.json(klines);
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  return httpServer;
}
