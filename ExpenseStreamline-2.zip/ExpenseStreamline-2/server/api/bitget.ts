import fetch from 'node-fetch';
import { generateSignature } from '../utils/crypto';
import type { PriceCandle } from '@shared/schema';

interface BitgetConfig {
  apiKey: string;
  secretKey: string;
  passphrase: string;
}

export class BitgetApi {
  private baseUrl = 'https://api.bitget.com';
  private apiKey: string;
  private secretKey: string;
  private passphrase: string;

  constructor(config: BitgetConfig) {
    this.apiKey = config.apiKey;
    this.secretKey = config.secretKey;
    this.passphrase = config.passphrase;
  }

  // Helper method to generate headers for authenticated requests
  private getHeaders(method: string, endpoint: string, body: any = null): Record<string, string> {
    const timestamp = Date.now().toString();
    const bodyString = body ? JSON.stringify(body) : '';
    
    const signature = generateSignature(
      timestamp,
      method,
      endpoint,
      bodyString,
      this.secretKey
    );

    return {
      'Content-Type': 'application/json',
      'ACCESS-KEY': this.apiKey,
      'ACCESS-SIGN': signature,
      'ACCESS-TIMESTAMP': timestamp,
      'ACCESS-PASSPHRASE': this.passphrase,
      'x-simulated-trading': '0' // 0 for real trading, 1 for simulated
    };
  }

  // Make an API request
  private async request<T>(
    method: string,
    endpoint: string,
    body: any = null
  ): Promise<T> {
    const url = this.baseUrl + endpoint;
    const headers = this.getHeaders(method, endpoint, body);
    
    const options: RequestInit = {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined
    };

    const response = await fetch(url, options);
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Bitget API error (${response.status}): ${errorText}`);
    }
    
    const data = await response.json();
    
    if (data.code !== '00000') {
      throw new Error(`Bitget API error: ${data.msg}`);
    }
    
    return data.data as T;
  }

  // Get account information
  async getAccountInfo() {
    return this.request<any>('GET', '/api/mix/v1/account/accounts');
  }

  // Get ticker information for a symbol
  async getTicker(symbol: string) {
    return this.request<any>('GET', `/api/spot/v1/market/ticker?symbol=${symbol}`);
  }

  // Get candlestick data
  async getKlines(symbol: string, period: string, limit: number = 100): Promise<PriceCandle[]> {
    const data = await this.request<any>(
      'GET', 
      `/api/spot/v1/market/candles?symbol=${symbol}&granularity=${period}&limit=${limit}`
    );
    
    // Transform to our candle format
    return data.map((item: any) => ({
      time: parseInt(item[0]),
      open: parseFloat(item[1]),
      high: parseFloat(item[2]),
      low: parseFloat(item[3]),
      close: parseFloat(item[4]),
      volume: parseFloat(item[5])
    }));
  }

  // Place a limit order
  async placeLimitOrder(
    symbol: string,
    side: 'buy' | 'sell',
    price: string,
    quantity: string
  ) {
    const body = {
      symbol,
      side,
      orderType: 'limit',
      force: 'normal',
      price,
      quantity
    };
    
    return this.request<any>('POST', '/api/spot/v1/trade/orders', body);
  }

  // Cancel an order
  async cancelOrder(symbol: string, orderId: string) {
    return this.request<any>('POST', '/api/spot/v1/trade/cancel-order', {
      symbol,
      orderId
    });
  }

  // Get order details
  async getOrder(symbol: string, orderId: string) {
    return this.request<any>('GET', `/api/spot/v1/trade/orderInfo?symbol=${symbol}&orderId=${orderId}`);
  }

  // Get open orders
  async getOpenOrders(symbol: string) {
    return this.request<any>('GET', `/api/spot/v1/trade/open-orders?symbol=${symbol}`);
  }

  // Get account balances
  async getBalances() {
    return this.request<any>('GET', '/api/spot/v1/account/assets');
  }

  // Calculate grid levels (helper function)
  calculateGridLevels(
    lowerPrice: number,
    upperPrice: number,
    gridCount: number,
    gridType: 'arithmetic' | 'geometric'
  ): number[] {
    const levels: number[] = [];
    
    if (gridType === 'arithmetic') {
      // Arithmetic grid - equal price difference between levels
      const step = (upperPrice - lowerPrice) / (gridCount - 1);
      for (let i = 0; i < gridCount; i++) {
        levels.push(lowerPrice + step * i);
      }
    } else {
      // Geometric grid - equal percentage difference between levels
      const ratio = Math.pow(upperPrice / lowerPrice, 1 / (gridCount - 1));
      for (let i = 0; i < gridCount; i++) {
        levels.push(lowerPrice * Math.pow(ratio, i));
      }
    }
    
    return levels;
  }
}
