import { 
  ApiKey, InsertApiKey, 
  TradingBot, InsertTradingBot,
  Transaction, InsertTransaction,
  DashboardStats,
  GridBotStats,
  PriceCandle
} from "@shared/schema";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  // API Keys
  getApiKey(id: number): Promise<ApiKey | undefined>;
  getApiKeys(): Promise<ApiKey[]>;
  createApiKey(apiKey: InsertApiKey, encryptionData: { iv: string, salt: string }): Promise<ApiKey>;
  deleteApiKey(id: number): Promise<void>;

  // Trading Bots
  getTradingBot(id: number): Promise<TradingBot | undefined>;
  getTradingBots(): Promise<TradingBot[]>;
  getActiveTradingBots(): Promise<TradingBot[]>;
  createTradingBot(bot: InsertTradingBot, gridData: number[]): Promise<TradingBot>;
  updateTradingBot(id: number, updates: Partial<TradingBot>): Promise<TradingBot | undefined>;
  deleteTradingBot(id: number): Promise<void>;
  
  // Transactions
  getTransactions(limit?: number): Promise<Transaction[]>;
  getTransactionsByBotId(botId: number): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  
  // Dashboard Stats
  getDashboardStats(): Promise<DashboardStats>;
  updateDashboardStats(stats: Partial<DashboardStats>): Promise<DashboardStats>;

  // Grid Bot Stats
  getBotStats(botId: number): Promise<GridBotStats | undefined>;
  
  // Price Data
  savePriceData(tradingPair: string, price: number): Promise<void>;
  getPriceHistory(tradingPair: string, timeframe: string, limit: number): Promise<PriceCandle[]>;
}

export class MemStorage implements IStorage {
  private apiKeys: Map<number, ApiKey>;
  private tradingBots: Map<number, TradingBot>;
  private transactions: Transaction[];
  private dashboardStats: DashboardStats;
  private priceHistory: Map<string, Map<string, PriceCandle[]>>;
  private currentId: { apiKey: number; tradingBot: number; transaction: number };

  constructor() {
    this.apiKeys = new Map();
    this.tradingBots = new Map();
    this.transactions = [];
    this.priceHistory = new Map();
    this.currentId = { apiKey: 1, tradingBot: 1, transaction: 1 };
    
    // Initialize default dashboard stats
    this.dashboardStats = {
      totalAssets: 0,
      dailyProfit: 0,
      dailyProfitPercentage: 0,
      activeBots: 0,
      totalBots: 0,
      completedTrades: 0,
      todayTrades: 0,
    };
  }

  // API Keys
  async getApiKey(id: number): Promise<ApiKey | undefined> {
    return this.apiKeys.get(id);
  }

  async getApiKeys(): Promise<ApiKey[]> {
    return Array.from(this.apiKeys.values());
  }

  async createApiKey(apiKey: InsertApiKey, encryptionData: { iv: string, salt: string }): Promise<ApiKey> {
    const id = this.currentId.apiKey++;
    const newApiKey: ApiKey = {
      ...apiKey,
      id,
      encryptionIv: encryptionData.iv,
      encryptionSalt: encryptionData.salt,
    };
    this.apiKeys.set(id, newApiKey);
    return newApiKey;
  }

  async deleteApiKey(id: number): Promise<void> {
    this.apiKeys.delete(id);
  }

  // Trading Bots
  async getTradingBot(id: number): Promise<TradingBot | undefined> {
    return this.tradingBots.get(id);
  }

  async getTradingBots(): Promise<TradingBot[]> {
    return Array.from(this.tradingBots.values());
  }

  async getActiveTradingBots(): Promise<TradingBot[]> {
    return Array.from(this.tradingBots.values()).filter(bot => bot.isActive);
  }

  async createTradingBot(bot: InsertTradingBot, gridData: number[]): Promise<TradingBot> {
    const id = this.currentId.tradingBot++;
    const newBot: TradingBot = {
      ...bot,
      id,
      createdAt: new Date(),
      gridData
    };
    this.tradingBots.set(id, newBot);
    
    // Update dashboard stats
    this.dashboardStats.totalBots += 1;
    if (newBot.isActive) {
      this.dashboardStats.activeBots += 1;
    }
    
    return newBot;
  }

  async updateTradingBot(id: number, updates: Partial<TradingBot>): Promise<TradingBot | undefined> {
    const bot = this.tradingBots.get(id);
    if (!bot) return undefined;
    
    // If we're changing active status, update dashboard stats
    if (updates.isActive !== undefined && updates.isActive !== bot.isActive) {
      this.dashboardStats.activeBots += updates.isActive ? 1 : -1;
    }
    
    const updatedBot = { ...bot, ...updates };
    this.tradingBots.set(id, updatedBot);
    return updatedBot;
  }

  async deleteTradingBot(id: number): Promise<void> {
    const bot = this.tradingBots.get(id);
    if (bot) {
      this.dashboardStats.totalBots -= 1;
      if (bot.isActive) {
        this.dashboardStats.activeBots -= 1;
      }
      this.tradingBots.delete(id);
    }
  }

  // Transactions
  async getTransactions(limit?: number): Promise<Transaction[]> {
    const sortedTransactions = [...this.transactions].sort((a, b) => 
      b.timestamp.getTime() - a.timestamp.getTime()
    );
    
    return limit ? sortedTransactions.slice(0, limit) : sortedTransactions;
  }

  async getTransactionsByBotId(botId: number): Promise<Transaction[]> {
    return this.transactions
      .filter(tx => tx.botId === botId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const id = this.currentId.transaction++;
    const newTransaction: Transaction = {
      ...transaction,
      id,
      timestamp: new Date()
    };
    
    this.transactions.push(newTransaction);
    
    // Update dashboard stats
    this.dashboardStats.completedTrades += 1;
    
    // Check if today
    const today = new Date();
    if (
      newTransaction.timestamp.getDate() === today.getDate() &&
      newTransaction.timestamp.getMonth() === today.getMonth() &&
      newTransaction.timestamp.getFullYear() === today.getFullYear()
    ) {
      this.dashboardStats.todayTrades += 1;
    }
    
    return newTransaction;
  }

  // Dashboard Stats
  async getDashboardStats(): Promise<DashboardStats> {
    return this.dashboardStats;
  }

  async updateDashboardStats(stats: Partial<DashboardStats>): Promise<DashboardStats> {
    this.dashboardStats = { ...this.dashboardStats, ...stats };
    return this.dashboardStats;
  }

  // Grid Bot Stats
  async getBotStats(botId: number): Promise<GridBotStats | undefined> {
    const bot = await this.getTradingBot(botId);
    if (!bot) return undefined;
    
    // Calculate bot profit in last 24h from transactions
    const oneDayAgo = new Date();
    oneDayAgo.setDate(oneDayAgo.getDate() - 1);
    
    const recentTxs = this.transactions.filter(
      tx => tx.botId === botId && tx.timestamp > oneDayAgo && tx.profit !== null
    );
    
    const profit24h = recentTxs.reduce((sum, tx) => {
      return sum + (tx.profit || 0);
    }, 0);
    
    // Approximate percentage based on bot investment amount
    const profit24hPercentage = (Number(profit24h) / Number(bot.investmentAmount)) * 100;
    
    return {
      id: bot.id,
      name: bot.name,
      tradingPair: bot.tradingPair,
      profit24h: Number(profit24h),
      profit24hPercentage: Number(profit24hPercentage),
      status: bot.isActive ? "active" : "stopped",
      gridRange: {
        lower: Number(bot.lowerPrice),
        upper: Number(bot.upperPrice),
      },
      gridLines: bot.gridLines,
      createdAt: bot.createdAt.toISOString(),
    };
  }

  // Price Data
  async savePriceData(tradingPair: string, price: number): Promise<void> {
    if (!this.priceHistory.has(tradingPair)) {
      this.priceHistory.set(tradingPair, new Map());
    }
    
    const pairData = this.priceHistory.get(tradingPair)!;
    
    // Use 1m as default timeframe for storing incoming prices
    const timeframe = '1m';
    if (!pairData.has(timeframe)) {
      pairData.set(timeframe, []);
    }
    
    const candles = pairData.get(timeframe)!;
    const now = new Date();
    
    // Create new candle
    const newCandle: PriceCandle = {
      time: now.getTime(),
      open: price,
      high: price,
      low: price,
      close: price,
      volume: 0, // We don't have volume information for single price updates
    };
    
    candles.push(newCandle);
    
    // Keep only last 1000 candles
    if (candles.length > 1000) {
      pairData.set(timeframe, candles.slice(candles.length - 1000));
    }
  }

  async getPriceHistory(tradingPair: string, timeframe: string, limit: number): Promise<PriceCandle[]> {
    if (!this.priceHistory.has(tradingPair)) {
      return [];
    }
    
    const pairData = this.priceHistory.get(tradingPair)!;
    
    if (!pairData.has(timeframe)) {
      return [];
    }
    
    const candles = pairData.get(timeframe)!;
    return candles.slice(-limit);
  }
}

export const storage = new MemStorage();
