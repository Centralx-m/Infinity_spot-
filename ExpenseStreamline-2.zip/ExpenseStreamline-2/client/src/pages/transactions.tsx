import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Transaction } from "@shared/schema";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  SiEthereum, 
  SiBitcoin, 
  SiSolana, 
  SiBinance, 
  SiXrp 
} from "react-icons/si";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Filter } from "lucide-react";

const getCryptoIcon = (pair: string) => {
  switch (pair.split('/')[0]) {
    case 'BTC':
      return <SiBitcoin className="h-6 w-6 text-amber-500" />;
    case 'ETH':
      return <SiEthereum className="h-6 w-6 text-slate-500" />;
    case 'SOL':
      return <SiSolana className="h-6 w-6 text-purple-500" />;
    case 'BNB':
      return <SiBinance className="h-6 w-6 text-yellow-500" />;
    case 'XRP':
      return <SiXrp className="h-6 w-6 text-blue-500" />;
    default:
      return <SiBitcoin className="h-6 w-6 text-amber-500" />;
  }
};

export default function Transactions() {
  const [limit, setLimit] = useState<number>(50);
  const [search, setSearch] = useState<string>("");
  const [filterType, setFilterType] = useState<string>("all");
  
  const { data: transactions = [], isLoading } = useQuery({
    queryKey: ['/api/transactions', { limit }],
    queryFn: async ({ queryKey }) => {
      const [url, { limit }] = queryKey as [string, { limit: number }];
      const response = await fetch(`${url}?limit=${limit}`);
      if (!response.ok) throw new Error('Failed to fetch transactions');
      return response.json();
    },
  });

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  // Filter transactions based on search and type
  const filteredTransactions = transactions.filter((tx: Transaction) => {
    const matchesSearch = search === "" || 
      tx.tradingPair.toLowerCase().includes(search.toLowerCase()) ||
      tx.botId.toString().includes(search);
    
    const matchesType = filterType === "all" || tx.type === filterType;
    
    return matchesSearch && matchesType;
  });

  return (
    <>
      <div className="px-6 py-8 bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-semibold">Transactions</h1>
            <p className="mt-1 text-slate-500 dark:text-slate-400">View and track all your trading activity</p>
          </div>
          <div className="mt-4 md:mt-0 flex gap-2">
            <div className="relative flex items-center">
              <Search className="absolute left-2.5 h-4 w-4 text-slate-400" />
              <Input
                type="text"
                placeholder="Search transactions..."
                className="pl-8 w-full md:w-auto"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="buy">Buy Only</SelectItem>
                <SelectItem value="sell">Sell Only</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <div className="p-6">
        <Card>
          <CardHeader>
            <CardTitle>Transaction History</CardTitle>
            <CardDescription>
              Complete history of all your bot trading activities
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Time</TableHead>
                    <TableHead>Bot</TableHead>
                    <TableHead>Trading Pair</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Price</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Value</TableHead>
                    <TableHead>Profit</TableHead>
                    <TableHead>Order ID</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    <TableRow>
                      <TableCell colSpan={9} className="text-center py-8">
                        Loading transactions...
                      </TableCell>
                    </TableRow>
                  ) : filteredTransactions.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={9} className="text-center py-8">
                        <div className="flex flex-col items-center">
                          <svg className="w-16 h-16 text-slate-300 dark:text-slate-700 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                          </svg>
                          <p className="text-slate-500 dark:text-slate-400">
                            {search || filterType !== "all" 
                              ? "No transactions match your filters" 
                              : "No transactions found. Start a bot to begin trading."}
                          </p>
                          {(search || filterType !== "all") && (
                            <Button 
                              variant="outline" 
                              className="mt-4"
                              onClick={() => {
                                setSearch("");
                                setFilterType("all");
                              }}
                            >
                              <Filter className="h-4 w-4 mr-2" />
                              Clear Filters
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredTransactions.map((tx: Transaction) => (
                      <TableRow key={tx.id}>
                        <TableCell className="whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">
                          {formatDate(tx.timestamp.toString())}
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-sm text-slate-900 dark:text-white">
                          Bot #{tx.botId}
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <div className="flex items-center space-x-2">
                            {getCryptoIcon(tx.tradingPair)}
                            <span className="font-mono text-sm text-slate-900 dark:text-white">
                              {tx.tradingPair}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <Badge 
                            variant={tx.type === "buy" ? "success" : "destructive"}
                            className="px-2 text-xs font-semibold"
                          >
                            {tx.type.toUpperCase()}
                          </Badge>
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <div className="font-mono text-sm text-slate-900 dark:text-white">
                            ${Number(tx.price).toFixed(2)}
                          </div>
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <div className="font-mono text-sm text-slate-900 dark:text-white">
                            {Number(tx.amount).toFixed(4)} {tx.tradingPair.split('/')[0]}
                          </div>
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <div className="font-mono text-sm text-slate-900 dark:text-white">
                            ${Number(tx.value).toFixed(2)}
                          </div>
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <div className="font-mono text-sm text-accent">
                            {tx.profit ? `+$${Number(tx.profit).toFixed(2)}` : "-"}
                          </div>
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          <div className="font-mono text-xs text-slate-500 truncate max-w-[120px]">
                            {tx.orderId}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
            
            {transactions.length > 0 && (
              <div className="mt-4 flex justify-between items-center">
                <div className="text-sm text-slate-500 dark:text-slate-400">
                  Showing {filteredTransactions.length} of {transactions.length} transactions
                </div>
                <Select 
                  value={limit.toString()} 
                  onValueChange={(value) => setLimit(parseInt(value))}
                >
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Results per page" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="25">25 per page</SelectItem>
                    <SelectItem value="50">50 per page</SelectItem>
                    <SelectItem value="100">100 per page</SelectItem>
                    <SelectItem value="250">250 per page</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </>
  );
}
