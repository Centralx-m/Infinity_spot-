import { Button } from "@/components/ui/button";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { StatsCard } from "@/components/dashboard/stats-card";
import { PriceChart } from "@/components/dashboard/price-chart";
import { TradingBotsTable } from "@/components/dashboard/trading-bots-table";
import { CreateBotForm } from "@/components/dashboard/create-bot-form";
import { TransactionsTable } from "@/components/dashboard/transactions-table";
import { DashboardStats } from "@shared/schema";
import { 
  Wallet, 
  TrendingUp, 
  LayoutList, 
  BarChartBig 
} from "lucide-react";

export default function Dashboard() {
  const [showCreateForm, setShowCreateForm] = useState(false);
  
  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ['/api/dashboard'],
  });
  
  return (
    <>
      {/* Dashboard Header */}
      <div className="px-6 py-8 bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-semibold">Trading Dashboard</h1>
            <p className="mt-1 text-slate-500 dark:text-slate-400">Manage your grid trading bots and monitor performance</p>
          </div>
          <div className="mt-4 md:mt-0 space-y-2 md:space-y-0 md:space-x-2 flex flex-col md:flex-row">
            <Button 
              onClick={() => setShowCreateForm(true)}
              className="inline-flex items-center"
            >
              <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
              </svg>
              Create New Bot
            </Button>
            <Button variant="outline" className="inline-flex items-center">
              <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"></path>
              </svg>
              Filter Results
            </Button>
          </div>
        </div>
      </div>

      {/* Dashboard Content */}
      <div className="p-6">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatsCard
            title="Total Assets"
            value={isLoading ? "Loading..." : `$${stats?.totalAssets.toFixed(2)}`}
            icon={<Wallet className="w-6 h-6" />}
            iconBgColor="bg-blue-100 dark:bg-blue-900"
            iconColor="text-primary"
          />

          <StatsCard
            title="Total Profit (24h)"
            value={isLoading ? "Loading..." : `$${stats?.dailyProfit.toFixed(2)}`}
            change={isLoading ? "" : `+${stats?.dailyProfitPercentage.toFixed(2)}%`}
            changeType="positive"
            icon={<TrendingUp className="w-6 h-6" />}
            iconBgColor="bg-green-100 dark:bg-green-900"
            iconColor="text-accent"
          />

          <StatsCard
            title="Active Bots"
            value={isLoading ? "Loading..." : String(stats?.activeBots)}
            additionalInfo={isLoading ? "" : `of ${stats?.totalBots} total`}
            icon={<LayoutList className="w-6 h-6" />}
            iconBgColor="bg-indigo-100 dark:bg-indigo-900"
            iconColor="text-secondary"
          />

          <StatsCard
            title="Completed Trades"
            value={isLoading ? "Loading..." : String(stats?.completedTrades)}
            change={isLoading ? "" : `+${stats?.todayTrades} today`}
            changeType="positive"
            icon={<BarChartBig className="w-6 h-6" />}
            iconBgColor="bg-amber-100 dark:bg-amber-900"
            iconColor="text-amber-600 dark:text-amber-400"
          />
        </div>

        {/* Price Chart */}
        <PriceChart />

        {/* Bot Creation Form */}
        <CreateBotForm />

        {/* Active Bots Table */}
        <TradingBotsTable />

        {/* Recent Transactions */}
        <TransactionsTable limit={5} />
      </div>
    </>
  );
}
