import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { CreateBotForm } from "@/components/dashboard/create-bot-form";
import { 
  SiEthereum, 
  SiBitcoin, 
  SiSolana, 
  SiBinance, 
  SiXrp 
} from "react-icons/si";
import { Pencil, Play, Pause, Trash2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

const getCryptoIcon = (pair: string) => {
  switch (pair.split('/')[0]) {
    case 'BTC':
      return <SiBitcoin className="h-8 w-8 text-amber-500" />;
    case 'ETH':
      return <SiEthereum className="h-8 w-8 text-slate-500" />;
    case 'SOL':
      return <SiSolana className="h-8 w-8 text-purple-500" />;
    case 'BNB':
      return <SiBinance className="h-8 w-8 text-yellow-500" />;
    case 'XRP':
      return <SiXrp className="h-8 w-8 text-blue-500" />;
    default:
      return <SiBitcoin className="h-8 w-8 text-amber-500" />;
  }
};

export default function Bots() {
  const { toast } = useToast();
  const [isCreateFormOpen, setIsCreateFormOpen] = useState(false);
  const [deleteBotId, setDeleteBotId] = useState<number | null>(null);
  
  const { data: bots = [], isLoading } = useQuery({
    queryKey: ['/api/bots'],
  });
  
  const toggleBotMutation = useMutation({
    mutationFn: async (botId: number) => {
      return apiRequest('POST', `/api/bots/${botId}/toggle`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bots'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard'] });
      toast({
        title: "Success",
        description: "Bot status updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update bot status: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  const deleteBotMutation = useMutation({
    mutationFn: async (botId: number) => {
      return apiRequest('DELETE', `/api/bots/${botId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bots'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard'] });
      toast({
        title: "Success",
        description: "Bot deleted successfully",
      });
      setDeleteBotId(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete bot: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  const handleToggleBot = (botId: number) => {
    toggleBotMutation.mutate(botId);
  };
  
  const handleDeleteBot = (botId: number) => {
    setDeleteBotId(botId);
  };
  
  return (
    <>
      <div className="px-6 py-8 bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-semibold">Trading Bots</h1>
            <p className="mt-1 text-slate-500 dark:text-slate-400">Manage your grid trading bots</p>
          </div>
          <div className="mt-4 md:mt-0">
            <Button onClick={() => setIsCreateFormOpen(true)}>
              Create New Bot
            </Button>
          </div>
        </div>
      </div>

      <div className="p-6">
        {isCreateFormOpen && (
          <CreateBotForm />
        )}
        
        <Card>
          <CardHeader>
            <CardTitle>Your Trading Bots</CardTitle>
            <CardDescription>
              View and manage all your grid trading bots
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Bot Name</TableHead>
                  <TableHead>Trading Pair</TableHead>
                  <TableHead>Grid Range</TableHead>
                  <TableHead>Grid Lines</TableHead>
                  <TableHead>Investment</TableHead>
                  <TableHead>Profit per Grid</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-4">
                      Loading bots...
                    </TableCell>
                  </TableRow>
                ) : bots.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8">
                      <div className="flex flex-col items-center">
                        <svg className="w-16 h-16 text-slate-300 dark:text-slate-700 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path>
                        </svg>
                        <p className="text-slate-500 dark:text-slate-400">
                          No trading bots found. Create your first bot to get started.
                        </p>
                        <Button 
                          className="mt-4" 
                          onClick={() => setIsCreateFormOpen(true)}
                        >
                          Create New Bot
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  bots.map((bot: any) => (
                    <TableRow key={bot.id}>
                      <TableCell>
                        <div className="font-medium">{bot.name}</div>
                        <div className="text-sm text-slate-500 dark:text-slate-400">
                          Created {new Date(bot.createdAt).toLocaleDateString()}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <div className="h-8 w-8 flex-shrink-0 mr-2">
                            {getCryptoIcon(bot.tradingPair)}
                          </div>
                          <span className="font-mono text-sm">
                            {bot.tradingPair}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="font-mono text-sm">
                          ${Number(bot.lowerPrice).toFixed(2)} - ${Number(bot.upperPrice).toFixed(2)}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">{bot.gridLines}</div>
                      </TableCell>
                      <TableCell>
                        <div className="font-mono text-sm">
                          ${Number(bot.investmentAmount).toFixed(2)}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="font-mono text-sm">
                          {Number(bot.profitPerGrid).toFixed(2)}%
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={bot.isActive ? "success" : "secondary"}>
                          {bot.isActive ? 'Active' : 'Stopped'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-1">
                          <Button variant="ghost" size="icon" className="text-primary">
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            className={bot.isActive ? "text-red-600" : "text-green-600"}
                            onClick={() => handleToggleBot(bot.id)}
                            disabled={toggleBotMutation.isPending}
                          >
                            {bot.isActive ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="text-red-600"
                            onClick={() => handleDeleteBot(bot.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteBotId !== null} onOpenChange={() => setDeleteBotId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Trading Bot</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this bot? This action cannot be undone and will stop all trading activities for this bot.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setDeleteBotId(null)}
            >
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={() => deleteBotId && deleteBotMutation.mutate(deleteBotId)}
              disabled={deleteBotMutation.isPending}
            >
              {deleteBotMutation.isPending ? "Deleting..." : "Delete Bot"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
