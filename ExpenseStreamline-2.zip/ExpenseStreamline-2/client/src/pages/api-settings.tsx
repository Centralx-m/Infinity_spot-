import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { AlertTriangle, Key, Shield, Trash2 } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

const apiKeySchema = z.object({
  name: z.string().min(1, "API Key name is required"),
  apiKey: z.string().min(1, "API Key is required"),
  apiSecret: z.string().min(1, "API Secret is required"),
  passphrase: z.string().min(1, "Passphrase is required"),
});

type ApiKeyFormValues = z.infer<typeof apiKeySchema>;

export default function ApiSettings() {
  const { toast } = useToast();
  const [isTestingKey, setIsTestingKey] = useState(false);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [deleteKeyId, setDeleteKeyId] = useState<number | null>(null);
  
  const { register, handleSubmit, reset, formState: { errors } } = useForm<ApiKeyFormValues>({
    resolver: zodResolver(apiKeySchema),
    defaultValues: {
      name: "",
      apiKey: "",
      apiSecret: "",
      passphrase: "",
    }
  });
  
  const { data: apiKeys = [], isLoading, refetch } = useQuery({
    queryKey: ['/api/keys'],
  });
  
  const addKeyMutation = useMutation({
    mutationFn: async (data: ApiKeyFormValues) => {
      return apiRequest('POST', '/api/keys', data);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "API key added successfully",
      });
      setIsAddDialogOpen(false);
      reset();
      refetch();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add API key: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  const deleteKeyMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest('DELETE', `/api/keys/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "API key deleted successfully",
      });
      setDeleteKeyId(null);
      refetch();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete API key: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  const testApiKeyMutation = useMutation({
    mutationFn: async (data: ApiKeyFormValues) => {
      return apiRequest('POST', '/api/keys/test', {
        apiKey: data.apiKey,
        apiSecret: data.apiSecret,
        passphrase: data.passphrase
      });
    },
    onSuccess: (data) => {
      toast({
        title: "API Key Test Successful",
        description: "The API key is valid and has been verified with Bitget.",
      });
    },
    onError: (error) => {
      toast({
        title: "API Key Test Failed",
        description: `Error: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  const onSubmitKey = (data: ApiKeyFormValues) => {
    addKeyMutation.mutate(data);
  };
  
  const handleTestKey = (data: ApiKeyFormValues) => {
    setIsTestingKey(true);
    testApiKeyMutation.mutate(data, {
      onSettled: () => setIsTestingKey(false)
    });
  };
  
  return (
    <>
      <div className="px-6 py-8 bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-semibold">API Settings</h1>
            <p className="mt-1 text-slate-500 dark:text-slate-400">Manage your Bitget API keys securely</p>
          </div>
          <div className="mt-4 md:mt-0">
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Key className="w-4 h-4 mr-2" />
                  Add New API Key
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New API Key</DialogTitle>
                  <DialogDescription>
                    Enter your Bitget API credentials. Your API secret and passphrase will be encrypted.
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmit(onSubmitKey)}>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="name" className="text-right">
                        Name
                      </Label>
                      <Input
                        id="name"
                        placeholder="Main Account"
                        className="col-span-3"
                        {...register("name")}
                      />
                      {errors.name && (
                        <p className="text-red-600 text-sm col-start-2 col-span-3">
                          {errors.name.message}
                        </p>
                      )}
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="apiKey" className="text-right">
                        API Key
                      </Label>
                      <Input
                        id="apiKey"
                        placeholder="Your Bitget API Key"
                        className="col-span-3"
                        {...register("apiKey")}
                      />
                      {errors.apiKey && (
                        <p className="text-red-600 text-sm col-start-2 col-span-3">
                          {errors.apiKey.message}
                        </p>
                      )}
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="apiSecret" className="text-right">
                        API Secret
                      </Label>
                      <Input
                        id="apiSecret"
                        type="password"
                        placeholder="Your Bitget API Secret"
                        className="col-span-3"
                        {...register("apiSecret")}
                      />
                      {errors.apiSecret && (
                        <p className="text-red-600 text-sm col-start-2 col-span-3">
                          {errors.apiSecret.message}
                        </p>
                      )}
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="passphrase" className="text-right">
                        Passphrase
                      </Label>
                      <Input
                        id="passphrase"
                        type="password"
                        placeholder="Your Bitget Passphrase"
                        className="col-span-3"
                        {...register("passphrase")}
                      />
                      {errors.passphrase && (
                        <p className="text-red-600 text-sm col-start-2 col-span-3">
                          {errors.passphrase.message}
                        </p>
                      )}
                    </div>
                  </div>
                  <Alert variant="warning" className="mb-4">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>Important</AlertTitle>
                    <AlertDescription>
                      Ensure your API key has appropriate permissions for trading. For security reasons, we recommend setting IP restrictions on your API key.
                    </AlertDescription>
                  </Alert>
                  <DialogFooter>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => handleTestKey(handleSubmit(data => data)())}
                      disabled={isTestingKey || addKeyMutation.isPending}
                    >
                      {isTestingKey ? "Testing..." : "Test Connection"}
                    </Button>
                    <Button type="submit" disabled={addKeyMutation.isPending}>
                      {addKeyMutation.isPending ? "Adding..." : "Add API Key"}
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>

      <div className="p-6">
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Your API Keys</CardTitle>
            <CardDescription>
              Manage your Bitget API keys. All secrets are stored encrypted in the database.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8">Loading API keys...</div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>API Key</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {apiKeys.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center py-8">
                        <div className="flex flex-col items-center">
                          <Shield className="h-16 w-16 text-slate-300 dark:text-slate-700 mb-4" />
                          <p className="text-slate-500 dark:text-slate-400">
                            No API keys found. Add your first API key to get started.
                          </p>
                          <Button 
                            className="mt-4" 
                            onClick={() => setIsAddDialogOpen(true)}
                          >
                            Add API Key
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ) : (
                    apiKeys.map((key: any) => (
                      <TableRow key={key.id}>
                        <TableCell className="font-medium">{key.name}</TableCell>
                        <TableCell>
                          <code className="bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded text-sm">
                            {key.apiKey ? "••••••••" + key.apiKey.substring(key.apiKey.length - 4) : "•••••••••••••••"}
                          </code>
                        </TableCell>
                        <TableCell>
                          <span className="px-2 py-1 rounded-full text-xs font-semibold bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300">
                            Active
                          </span>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-red-600 hover:text-red-800 dark:hover:text-red-400"
                            onClick={() => setDeleteKeyId(key.id)}
                          >
                            <Trash2 className="h-4 w-4 mr-1" />
                            Delete
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle>API Key Security</CardTitle>
            <CardDescription>
              Best practices for securely managing your API keys
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="list-disc pl-5 space-y-2">
              <li>Create API keys with the minimum necessary permissions</li>
              <li>Set IP restrictions to only allow trusted IP addresses</li>
              <li>Enable two-factor authentication on your Bitget account</li>
              <li>Regularly review active API keys and revoke unused ones</li>
              <li>Never share your API secret or passphrase with anyone</li>
              <li>Use different API keys for different applications</li>
            </ul>
          </CardContent>
        </Card>
      </div>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteKeyId !== null} onOpenChange={() => setDeleteKeyId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete API Key</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this API key? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setDeleteKeyId(null)}
            >
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={() => deleteKeyId && deleteKeyMutation.mutate(deleteKeyId)}
              disabled={deleteKeyMutation.isPending}
            >
              {deleteKeyMutation.isPending ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
