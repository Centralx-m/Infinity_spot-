import { useQuery } from "@tanstack/react-query";
import { PriceCandle } from "@shared/schema";

/**
 * Hook to fetch price data from the Bitget API through the backend
 * @param symbol Trading pair symbol (e.g., "BTCUSDT")
 * @param timeframe Timeframe for candles (e.g., "1m", "5m", "1h", "1d")
 * @param limit Number of candles to fetch (default: 100)
 * @returns Price data and loading state
 */
export function usePriceData(
  symbol: string,
  timeframe: string = "1d",
  limit: number = 100
) {
  return useQuery<PriceCandle[]>({
    queryKey: ['/api/market', symbol, 'klines', { period: timeframe, limit }],
    queryFn: async ({ queryKey }) => {
      const [, symbol, endpoint, params] = queryKey as [string, string, string, { period: string, limit: number }];
      
      const queryParams = new URLSearchParams({
        period: params.period,
        limit: params.limit.toString()
      }).toString();
      
      const response = await fetch(`/api/market/${symbol}/${endpoint}?${queryParams}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch price data');
      }
      
      return response.json();
    },
    refetchInterval: 60000, // Refetch every minute for real-time updates
    // Only fetch if we have a valid symbol
    enabled: !!symbol,
    // Maintain previous data while new data is loading
    keepPreviousData: true
  });
}

/**
 * Hook to fetch the current ticker price for a symbol
 * @param symbol Trading pair symbol (e.g., "BTCUSDT")
 * @returns Current ticker data and loading state
 */
export function useTickerData(symbol: string) {
  return useQuery({
    queryKey: ['/api/market', symbol, 'ticker'],
    queryFn: async ({ queryKey }) => {
      const [, symbol] = queryKey as [string, string, string];
      
      const response = await fetch(`/api/market/${symbol}/ticker`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch ticker data');
      }
      
      return response.json();
    },
    refetchInterval: 15000, // Refetch every 15 seconds for real-time price updates
    enabled: !!symbol
  });
}

/**
 * Get aggregated price data statistics
 * @param priceData Array of price candles
 * @returns Statistics about the price data
 */
export function usePriceStatistics(priceData: PriceCandle[] | undefined) {
  if (!priceData || priceData.length === 0) {
    return {
      currentPrice: 0,
      highPrice: 0,
      lowPrice: 0,
      priceChange: 0,
      priceChangePercent: 0,
      volume: 0
    };
  }

  const latestCandle = priceData[priceData.length - 1];
  const firstCandle = priceData[0];

  const currentPrice = latestCandle.close;
  const highPrice = Math.max(...priceData.map(candle => candle.high));
  const lowPrice = Math.min(...priceData.map(candle => candle.low));
  const priceChange = currentPrice - firstCandle.open;
  const priceChangePercent = (priceChange / firstCandle.open) * 100;
  const volume = priceData.reduce((total, candle) => total + candle.volume, 0);

  return {
    currentPrice,
    highPrice,
    lowPrice,
    priceChange,
    priceChangePercent,
    volume
  };
}
