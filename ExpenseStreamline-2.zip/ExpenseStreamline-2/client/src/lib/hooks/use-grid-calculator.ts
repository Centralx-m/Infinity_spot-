import { useMemo } from "react";
import { calculateGridLevels, calculateGridTradeConfig } from "../utils/bitget";

interface GridCalculatorProps {
  lowerPrice: number;
  upperPrice: number;
  gridLines: number;
  profitPerGrid: number;
  investmentAmount: number;
  gridType?: 'arithmetic' | 'geometric';
  basePrice?: number;
}

interface GridCalculatorResult {
  gridLevels: number[];
  dailyProfit: number;
  dailyProfitPercentage: number;
  monthlyProfit: number;
  monthlyProfitPercentage: number;
  annualProfit: number;
  annualProfitPercentage: number;
  profitPerTrade: number;
  estimatedCompletedGrids: number;
}

/**
 * Hook to calculate grid trading statistics
 * @param props Grid trading parameters
 * @returns Calculated grid statistics
 */
export function useGridCalculator({
  lowerPrice,
  upperPrice,
  gridLines,
  profitPerGrid,
  investmentAmount,
  gridType = 'geometric',
  basePrice
}: GridCalculatorProps): GridCalculatorResult {
  // Default to the middle of the grid if basePrice is not provided
  const currentPrice = basePrice || ((upperPrice + lowerPrice) / 2);
  
  return useMemo(() => {
    // Basic validation to prevent errors
    if (!lowerPrice || !upperPrice || !gridLines || lowerPrice >= upperPrice || gridLines < 2) {
      return {
        gridLevels: [],
        dailyProfit: 0,
        dailyProfitPercentage: 0,
        monthlyProfit: 0,
        monthlyProfitPercentage: 0,
        annualProfit: 0,
        annualProfitPercentage: 0,
        profitPerTrade: 0,
        estimatedCompletedGrids: 0
      };
    }

    // Calculate grid levels
    const gridLevels = calculateGridLevels({
      lowerPrice,
      upperPrice,
      gridLines,
      gridType
    });

    // Calculate profit per trade
    const profitPerTrade = (profitPerGrid / 100) * (investmentAmount / gridLines);
    
    // Estimate number of completed grids per day based on volatility
    // This is a simplified model; real-world results will vary
    const volatilityFactor = 0.02; // Assume 2% price movement per day on average
    const priceRange = upperPrice - lowerPrice;
    const estimatedPriceMovement = currentPrice * volatilityFactor;
    const estimatedCompletedGrids = Math.min(
      (estimatedPriceMovement / (priceRange / gridLines)) * 2, // multiply by 2 for round trips
      gridLines * 2 // Cap at 2x grid lines as maximum daily potential
    );
    
    // Daily profit calculation
    const dailyProfit = profitPerTrade * estimatedCompletedGrids;
    const dailyProfitPercentage = (dailyProfit / investmentAmount) * 100;
    
    // Monthly profit calculation (30 days)
    const monthlyProfit = dailyProfit * 30;
    const monthlyProfitPercentage = dailyProfitPercentage * 30;
    
    // Annual profit calculation (365 days)
    // Using compound interest formula for more accurate estimation
    const annualProfitPercentage = (Math.pow(1 + dailyProfitPercentage / 100, 365) - 1) * 100;
    const annualProfit = (investmentAmount * annualProfitPercentage) / 100;

    return {
      gridLevels,
      dailyProfit,
      dailyProfitPercentage,
      monthlyProfit,
      monthlyProfitPercentage,
      annualProfit,
      annualProfitPercentage,
      profitPerTrade,
      estimatedCompletedGrids
    };
  }, [lowerPrice, upperPrice, gridLines, profitPerGrid, investmentAmount, gridType, currentPrice]);
}
