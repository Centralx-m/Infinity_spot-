// This is a helper utility to work with the Bitget API on the client side
// It provides methods to format data and calculate parameters for grid trading

export interface GridParams {
  lowerPrice: number;
  upperPrice: number;
  gridLines: number;
  gridType: 'arithmetic' | 'geometric';
}

export interface GridLevel {
  price: number;
  buyAmount: number;
  sellAmount: number;
}

export interface GridTradeConfig {
  levels: GridLevel[];
  totalBuyAmount: number;
  totalSellAmount: number;
  profitPerTrade: number;
  estimatedProfit: number;
}

/**
 * Calculates grid levels for a grid trading strategy
 * @param params Grid parameters
 * @param investmentAmount Total investment amount in USDT
 * @param basePrice Current base price of the asset
 * @returns An array of price levels
 */
export function calculateGridLevels(
  params: GridParams
): number[] {
  const { lowerPrice, upperPrice, gridLines, gridType } = params;
  const levels: number[] = [];
  
  if (gridType === 'arithmetic') {
    // Arithmetic grid - equal price difference between levels
    const step = (upperPrice - lowerPrice) / (gridLines - 1);
    for (let i = 0; i < gridLines; i++) {
      levels.push(lowerPrice + step * i);
    }
  } else {
    // Geometric grid - equal percentage difference between levels
    const ratio = Math.pow(upperPrice / lowerPrice, 1 / (gridLines - 1));
    for (let i = 0; i < gridLines; i++) {
      levels.push(lowerPrice * Math.pow(ratio, i));
    }
  }
  
  return levels;
}

/**
 * Calculate detailed grid trading configuration
 * @param params Grid parameters
 * @param investmentAmount Total investment amount in USDT
 * @param basePrice Current price of the asset
 * @param profitPerGrid Profit percentage per grid
 * @returns Grid trading configuration
 */
export function calculateGridTradeConfig(
  params: GridParams,
  investmentAmount: number,
  basePrice: number,
  profitPerGrid: number
): GridTradeConfig {
  const { lowerPrice, upperPrice, gridLines } = params;
  const levels = calculateGridLevels(params);
  
  // Calculate trade amounts
  const gridSpread = upperPrice - lowerPrice;
  const amountPerGrid = investmentAmount / gridLines;
  
  // Create grid levels with buy/sell amounts
  const gridLevels: GridLevel[] = levels.map(price => {
    // Calculate buy amount based on price
    const buyAmount = amountPerGrid / price;
    // Sell amount is slightly less to account for fees
    const sellAmount = buyAmount * 0.999;
    
    return {
      price,
      buyAmount,
      sellAmount
    };
  });
  
  // Calculate total buy/sell amounts
  const totalBuyAmount = gridLevels.reduce((sum, level) => sum + level.buyAmount, 0);
  const totalSellAmount = gridLevels.reduce((sum, level) => sum + level.sellAmount, 0);
  
  // Calculate profit per trade and estimated profit
  const profitPerTrade = profitPerGrid / 100 * investmentAmount / gridLines;
  
  // Assume average of 2 trades per day per grid line for estimation
  const dailyTrades = gridLines * 2;
  const estimatedDailyProfit = profitPerTrade * dailyTrades;
  
  return {
    levels: gridLevels,
    totalBuyAmount,
    totalSellAmount,
    profitPerTrade,
    estimatedProfit: estimatedDailyProfit
  };
}

/**
 * Format trading pair for Bitget API
 * @param pair Trading pair (e.g., "BTC/USDT")
 * @returns Formatted symbol for Bitget API
 */
export function formatTradingPair(pair: string): string {
  return pair.replace('/', '');
}

/**
 * Calculate estimated annual profit based on daily profit
 * @param dailyProfit Daily profit amount
 * @returns Annualized profit
 */
export function calculateAnnualizedProfit(dailyProfit: number): number {
  // Compound daily profit for 365 days
  return (Math.pow(1 + dailyProfit, 365) - 1) * 100;
}

/**
 * Format large numbers with appropriate suffixes (K, M, B)
 * @param value Number to format
 * @returns Formatted string
 */
export function formatLargeNumber(value: number): string {
  if (value >= 1_000_000_000) {
    return `${(value / 1_000_000_000).toFixed(2)}B`;
  } else if (value >= 1_000_000) {
    return `${(value / 1_000_000).toFixed(2)}M`;
  } else if (value >= 1_000) {
    return `${(value / 1_000).toFixed(2)}K`;
  } else {
    return value.toFixed(2);
  }
}
